<?php


require_once($_SERVER['DOCUMENT_ROOT'] . "/ejercicio1_mantenimiento_estado/includes/functions.php");

/*

    Consultas preparadas
    --------------------

    Ponemos los datos en un formulario.

    Recogemos los datos que hayan enviado.

    Creamos la cadena con la cláusula WHERE.

    Creamos la consulta preparada.

    Vinculamos los datos.

    Ejecutar la consulta.

    Procesar los resultados.

*/



    inicio_html("Consultas simples con mysqli", ['../../styles/general.css', '../../styles/tablas.css']);
    // Parámetros para abrir conexión con la base de datos
    $servidor = "mysql";
    $puerto = 3306;
    $usuario = "usuario";
    $clave = "usuario";
    $schema = "tiendaol";
    ?>

    <form action="<?=$_SERVER['PHP_SELF']?>" method="POST">
        <fieldset>
            <legend>Criterios de búsqueda</legend>
            <label for="referencia">Referencia</label>
            <input type="text" name="referencia" id="referencia">
            <label for="descripcion">Descripción</label>
            <input type="text" name="descripcion" id="descripcion">
            <label for="pvp">PVP</label>
            <input type="text" name="pvp" id="pvp">
            <label for="categoria">Categorias</label>
            <input type="text" name="categoria" id="categoria">
            <input type="submit" name="operacion" id="operacion">
        </fieldset>
    </form>

    <?php

    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        $referencia = filter_input(INPUT_POST, 'referencia', FILTER_SANITIZE_SPECIAL_CHARS);
        $descripcion = filter_input(INPUT_POST, 'descripcion', FILTER_SANITIZE_SPECIAL_CHARS);
        $pvp = filter_input(INPUT_POST, 'pvp', FILTER_SANITIZE_NUMBER_FLOAT);
        $pvp = filter_var($pvp, FILTER_VALIDATE_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $categoria = filter_input(INPUT_POST, 'categoria', FILTER_SANITIZE_SPECIAL_CHARS);

        if (empty($referencia)){

        }

    }

    try{
        // Genero la conexión
        $conexion = new mysqli($servidor, $usuario, $clave, $schema, $puerto);
        // Genero la consulta preparada
        $sentencia = "SELECT referencia, descripcion, pvp, und_vendidas ";
        $sentencia.= "FROM articulo ";
        $sentencia.= "WHERE pvp > ? AND categoria = ? AND und_vendidas > ?";

        $smtm = $conexion->prepare($sentencia); // Objeto msqli_stmt;

        // Vinculamos los parámetros de búsqueda.
        $pvp_minimo = 4.75;
        $categoria = "CARN";
        $und_vendidas = 5;

        $categoria = $conexion->escape_string($categoria);

        // Vinculamos los valores a los parámetros
        // Tipo de datos: UNA cadena de caracteres que indica el tipo de datos de cada parámetro usando una úniica letra y en el orden en el
        //                que aparecen en la sentencia
        // Los tipos de datos son s -> cadena, i->entero, d->float, s->fecha
        $tipos = "dsi";
        $smtm->bind_param($tipos, $pvp_minimo, $categoria, $und_vendidas);

        // Ejecutar la sentencia.
        $resultado = $smtm->execute(); // Devuelve un boolean.

        // Obtener los resultados
        $resultset = $smtm->get_result(); // Devuelve el objeto de resultset.

        // Procesamos los resultados.
        echo "<table><thead><tr><th>Referencia</th><th>Descripción</th><th>PVP</th><th>Unidades Vendidas</th></tr></thead>";
        echo "<tbody>";
        while($fila = $resultset->fetch_assoc()){
            echo "<tr>";
            echo "<td>{$fila['referencia']}</td>";
            echo "<td>{$fila['descripcion']}</td>";
            echo "<td>{$fila['pvp']}</td>";
            echo "<td>{$fila['und_vendidas']}</td>";
            echo "</tr>";
        }
        echo "</tbody></table>";
        echo "<p>¿Cuántos registros ha habido? . " . $resultset->num_rows . "</p>";

        // Libero los recursos del resultset.
        $resultset->close();

    } catch (mysqli_sql_exception $e) {

    } finally{

    }



    fin_html();

?>